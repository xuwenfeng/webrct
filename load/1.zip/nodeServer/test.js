const axios = require('axios');
const config = require('./config/index');
const fs = require('fs'); // 载入fs模块

const searchData = (url) => {
    var promise = new Promise((resolve,reject) => {
        try{
            axios.get(url,{
                headers:{
                    'Content-Type':'application/x-www-form-urlencoded'
                }
            })
            .then(function (response) {
                resolve(response);
            })
            .catch(function (error) {
                resolve(error);
            });
        }
        catch(error){
            reject(error);
        }
    });
    return promise;
}

const savefile = (fileName,content) => {
    fs.writeFile(`./file/${fileName}.json`, content, function(err) {
        if (err) {
            throw err;
        }
    });
}

const toUrl = (search) => {
    var params = '';
    for(var i in search){
        params = params + '&' + i + '=' + encodeURIComponent(search[i])
    }
    return config.poiAbroad.url + '?' + params.substr(1);
}

const dealData = (fileName,result) => {
    let _result = '';
    switch(result.status){
        case 200:
            //保存文件
            //savefile(fileName,'');
            //console.log(result.data.total);
            _result = result.data;
        break;
    }
    return _result;
}

const getData = async (query,region) => {
    let search = {
        query: query,
        page_size: 20,
        page_num: 0,
        scope: 2,
        region: region,
        output: 'json',
        ak: config.ak
    };
    let url = toUrl(search);
    let result = await searchData(url);
    let fileName = query + '.' + region;
    let _result = dealData(fileName,result);
    return _result;
}

module.exports = {
    getData
}



