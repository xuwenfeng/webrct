var express = require('express');
var router = express.Router();
var nodeServer = require('../nodeServer/test');

/* GET home page. */
router.get('/',async function(req, res, next) {
   
    let _query = req.query.query;
    let _region = req.query.region
    let result = await nodeServer.getData(_query,_region);
    

    //console.log(result);

    res.send(result);

//    let region = ['纽约'];
// let stop = false;

// region.map(function(_region){
//     config.keyword.map(function(_query){
//         if(stop == false) getData(_query,_region);
//         stop = true
//     });
// })


    

});

module.exports = router;